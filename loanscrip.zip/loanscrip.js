document.getElementById('loan-form').addEventListener('submit', function(e) {
    // Prevent default form submission
    e.preventDefault();

    // UI variables
    const amount = parseFloat(document.getElementById('amount').value);
    const interest = parseFloat(document.getElementById('interest').value);
    const years = parseFloat(document.getElementById('years').value);

    // Calculate monthly payment
    const principal = amount;
    const calculatedInterest = interest / 100 / 12; // Convert annual interest rate to monthly
    const calculatedPayments = years * 12; // Total number of payments

    // Formula: M = P[r(1+r)^n]/[(1+r)^n-1]
    const x = Math.pow(1 + calculatedInterest, calculatedPayments);
    const monthly = (principal * x * calculatedInterest) / (x - 1);

    // Check if monthly payment is a finite number
    if (isFinite(monthly)) {
        // Update the UI with the results
        document.getElementById('monthly-payment').textContent = monthly.toFixed(2);
        document.getElementById('total-payment').textContent = (monthly * calculatedPayments).toFixed(2);
        document.getElementById('total-interest').textContent = ((monthly * calculatedPayments) - principal).toFixed(2);

        // Show results
        document.getElementById('results').style.display = 'block';
    } else {
        alert('Please enter valid numbers.');
    }
});
